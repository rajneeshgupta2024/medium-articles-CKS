package com.example.webhook.model;

public class AdmissionResponse {
    private String uid;
    private boolean allowed;
    private Status status;

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public boolean isAllowed() { return allowed; }
    public void setAllowed(boolean allowed) { this.allowed = allowed; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
}
