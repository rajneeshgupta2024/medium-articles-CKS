package com.example.webhook.controller;

import com.example.webhook.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class AdmissionController {

    private final ObjectMapper mapper = new ObjectMapper();

    @PostMapping(path = "/validate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public AdmissionReview handle(@RequestBody AdmissionReview review) {
        AdmissionRequest req = review.getRequest();
        AdmissionResponse resp = new AdmissionResponse();
        resp.setUid(req.getUid());

        try {
            JsonNode obj = mapper.readTree(mapper.writeValueAsString(req.getObject()));
            JsonNode team = obj.at("/metadata/labels/team");
            if (team.isMissingNode() || team.isNull() || team.asText().isEmpty()) {
                resp.setAllowed(false);
                resp.setStatus(new Status("Failure", "Missing required label 'team' under metadata.labels'"));
            } else {
                resp.setAllowed(true);
            }
        } catch (Exception e) {
            resp.setAllowed(false);
            resp.setStatus(new Status("Failure", "Error parsing object: " + e.getMessage()));
        }

        AdmissionReview out = new AdmissionReview();
        out.setResponse(resp);
        return out;
    }
}
