package com.example.webhook.model;

public class Status {
    private String reason;
    private String message;
    public Status() {}
    public Status(String reason, String message) { this.reason = reason; this.message = message; }
    public String getReason() { return reason; }
    public void setReason(String r) { this.reason = r; }
    public String getMessage() { return message; }
    public void setMessage(String m) { this.message = m; }
}
