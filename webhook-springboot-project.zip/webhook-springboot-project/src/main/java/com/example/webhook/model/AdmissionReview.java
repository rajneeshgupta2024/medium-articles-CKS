package com.example.webhook.model;

public class AdmissionReview {
    private AdmissionRequest request;
    private AdmissionResponse response;
    public AdmissionRequest getRequest() { return request; }
    public void setRequest(AdmissionRequest r) { this.request = r; }
    public AdmissionResponse getResponse() { return response; }
    public void setResponse(AdmissionResponse r) { this.response = r; }
}
