package com.example.webhook.model;

public class AdmissionRequest {
    private String uid;
    private Object object; // raw object - Jackson will bind to LinkedHashMap

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public Object getObject() { return object; }
    public void setObject(Object object) { this.object = object; }
}
