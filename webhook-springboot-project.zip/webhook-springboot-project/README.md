# Kubernetes Admission Webhook (Spring Boot) - GitHub-ready project

This repository contains a minimal **Validating Admission Webhook** implemented in Java (Spring Boot).
It rejects any Pod that does not have the label `team` under `metadata.labels`.

## Contents
- `pom.xml` - Maven build
- Java source under `src/main/java/com/example/webhook/...`
- `Dockerfile` - container image
- `k8s/` - Kubernetes manifests (namespace, deployment, service, secret template, validating webhook configuration)
- `README.md` - this file

## How to run locally / build
1. Build jar:
   ```bash
   mvn -DskipTests package
   ```
2. Build Docker image:
   ```bash
   docker build -t <YOUR_REGISTRY>/webhook:latest .
   docker push <YOUR_REGISTRY>/webhook:latest
   ```
3. Create TLS secret and deploy manifests (see k8s/ files for instructions).

## Notes
- This is a minimal example intended for learning and testing.
- For production, add proper logging, metrics, RBAC, readiness/liveness probes, better error handling, and certificate automation (cert-manager).
